# V2 修正

本交接包已在原影像工坊补丁基础上加入成本保护：

- /api/video/create
- /api/video/cancel
- /api/video/upload/token
- /api/video/upload/commit

以上接口只接受用户请求头里的个人 BizyAir 调用码，不再使用服务器 .env 的 BizyAir Key 兜底。

未修改 /api/bizyair/* 旧接口。
