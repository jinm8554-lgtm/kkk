# BACAO-AIGC-MUSEUM / 影像工坊提交交接说明

## 本地提交

- Branch: feat/video-lab-cinema
- Commit: d9dda5ee76e08c0a054383c94df319c91c811136
- Message: feat: add video lab cinema generation

## 变更范围

只包含以下 4 个目标文件：

- client/src/AppRouter.tsx
- client/src/pages/Home.tsx
- client/src/pages/VideoLab.tsx
- server/bizyairProxy.ts

## 功能摘要

新增 /video-lab「影像工坊」页面与通用视频生成接口：

- 页面标题保持「影像工坊」，不是单模型标题。
- Veo 是第一个引擎 Tab。
- Wan / Grok 保持「即将开放」。
- 已实装三种 Veo 模式：
  - 文生视频
  - 单图生视频
  - 首尾帧转场
- 参考图像导演保持「即将开放」。
- 生成结果优先在影院大屏 video 标签内预览。
- 下载视频、复制链接只是辅助按钮。
- 不包含积分消耗预测。
- 新增接口为 /api/video/*，不改 /zimage、/studio、/admin 核心逻辑。

## 后端接口

新增：

- POST /api/video/create
- POST /api/video/cancel
- GET /api/video/upload/token
- POST /api/video/upload/commit

原 /api/bizyair/* 图片生成、上传、任务查询接口仍保留。


## v2 修正说明：影像工坊成本保护

已按正式服上线前要求修正 /api/video/*：

- POST /api/video/create
- POST /api/video/cancel
- GET /api/video/upload/token
- POST /api/video/upload/commit

这些视频接口现在只读取请求头中的用户个人 BizyAir 调用码：

```ts
const key = getRequestBizyairKey(req)
```

不再 fallback 到服务器 .env 里的 BizyAir Key：

```ts
// 已移除：getRequestBizyairKey(req) || getServerBizyairKey()
```

如果用户没有配置个人调用码，返回：

```json
{ "success": false, "error": "请先在调用码保险箱配置个人 BizyAir 调用码" }
```

该修正只影响新增的 /api/video/*，不影响原有 /api/bizyair/*。

## 安全说明

- 未提交 .env、.env.local、数据库文件、node_modules、dist。
- 未在 client/src 中硬编码 BizyAir API Key、Bearer Token 或 Authorization 密钥值。
- 曾提供的 GitHub token 不在本交接包内，也未写入仓库文件或远程 URL。
- 建议立即吊销曾发出的 GitHub token。

## 验证

已执行 pnpm build，通过。

Vite 仅提示 chunk size warning，不影响构建成功。

## 为什么需要交接包

本地 commit 已成功，但从当前机器执行 git push origin feat/video-lab-cinema 时，连接 GitHub HTTPS 失败：

- Recv failure: Connection was reset
- Empty reply from server
- Failed to connect to github.com port 443

这属于当前机器到 GitHub 的网络连接问题，不是代码构建失败，也不是明确的认证失败。

## 建议处理方式

在网络可访问 GitHub 的环境中任选一种：

1. 直接推送本地分支：

   git push origin feat/video-lab-cinema

2. 或应用补丁：

   git checkout -b feat/video-lab-cinema dc7dd689cb4e4de6d10d742921ddfb53cf0ab214
   git am 0001-feat-add-video-lab-cinema-generation.patch
   pnpm build
   git push origin feat/video-lab-cinema

不要部署正式服，除非另行确认。
